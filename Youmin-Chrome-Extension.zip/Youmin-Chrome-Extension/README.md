# Youmin-Chrome-Extension
Minimal Youtube Extension for Chrome

Just search and only watch you actually need.

- No thumbnails
- No comments
- No recommendations

In case you want to see the video preview, hover over the thumbnail.
